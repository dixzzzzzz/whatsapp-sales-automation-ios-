import { StatusBar } from "expo-status-bar";
import { useCallback, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { WebView } from "react-native-webview";

const APP_URL = "https://whatsapp-sal-gvqunbuq.manus.space";

export default function App() {
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  const reload = useCallback(() => {
    setFailed(false);
    setLoading(true);
    setReloadKey((value) => value + 1);
  }, []);

  if (failed) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <StatusBar style="dark" />
        <View style={styles.errorScreen}>
          <View style={styles.logo}><Text style={styles.logoText}>W</Text></View>
          <Text style={styles.title}>No pudimos cargar el panel</Text>
          <Text style={styles.subtitle}>
            Comprueba tu conexión a internet y vuelve a intentarlo.
          </Text>
          <Pressable onPress={reload} style={({ pressed }) => [styles.button, pressed && styles.pressed]}>
            <Text style={styles.buttonText}>Reintentar</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar style="dark" />
      <View style={styles.container}>
        {loading && (
          <View style={styles.loadingOverlay}>
            <View style={styles.logo}><Text style={styles.logoText}>W</Text></View>
            <ActivityIndicator size="small" color="#0f766e" />
            <Text style={styles.loadingText}>Abriendo tu panel...</Text>
          </View>
        )}
        <WebView
          key={reloadKey}
          source={{ uri: APP_URL }}
          style={styles.webview}
          originWhitelist={["https://*"]}
          javaScriptEnabled
          domStorageEnabled
          sharedCookiesEnabled
          thirdPartyCookiesEnabled
          startInLoadingState
          onLoadStart={() => setLoading(true)}
          onLoadEnd={() => setLoading(false)}
          onError={() => {
            setLoading(false);
            setFailed(true);
          }}
          allowsBackForwardNavigationGestures
          setSupportMultipleWindows={false}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: "#fbfbfa" },
  container: { flex: 1 },
  webview: { flex: 1, backgroundColor: "#fbfbfa" },
  loadingOverlay: {
    ...StyleSheet.absoluteFill,
    zIndex: 2,
    alignItems: "center",
    justifyContent: "center",
    gap: 14,
    backgroundColor: "#fbfbfa",
  },
  errorScreen: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
    backgroundColor: "#fbfbfa",
  },
  logo: {
    width: 64,
    height: 64,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#173b3b",
    marginBottom: 24,
  },
  logoText: { color: "#f2c14e", fontSize: 34, fontWeight: "800" },
  title: { color: "#173b3b", fontSize: 24, fontWeight: "700", textAlign: "center" },
  subtitle: { color: "#64748b", fontSize: 15, lineHeight: 22, textAlign: "center", marginTop: 10, marginBottom: 24 },
  loadingText: { color: "#64748b", fontSize: 14 },
  button: { borderRadius: 12, backgroundColor: "#0f766e", paddingHorizontal: 24, paddingVertical: 13 },
  buttonText: { color: "#fff", fontSize: 15, fontWeight: "700" },
  pressed: { opacity: 0.82, transform: [{ scale: 0.98 }] },
});
