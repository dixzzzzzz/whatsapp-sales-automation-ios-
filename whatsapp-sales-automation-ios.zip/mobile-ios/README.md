# WhatsApp Sales Automation iOS

Cliente iOS Expo conectado al backend publicado en `https://whatsapp-sal-gvqunbuq.manus.space`. La aplicación conserva la funcionalidad del sistema web: autenticación, contactos, campañas, conversaciones, IA, configuración y logs. Se usa `react-native-webview` para que el backend siga siendo una única fuente de verdad y para evitar duplicar la lógica de WhatsApp Cloud API.

## Validación local

```bash
npm install
npx expo config --type public
npx tsc --noEmit
npx expo start
```

Puedes probarla con Expo Go para validar la navegación web. Para instalar un `.ipa`, necesitas una cuenta Apple Developer y una cuenta de Expo/EAS.

## Generar IPA firmado

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform ios --profile preview
```

EAS solicitará o creará los certificados y provisioning profiles de Apple. Al finalizar entregará una URL para descargar el artefacto iOS. Para una distribución de App Store/TestFlight usa:

```bash
eas build --platform ios --profile production
eas submit --platform ios
```

El `.ipa` no puede firmarse completamente en este sandbox sin las credenciales/certificados de Apple del propietario. La app sí está preparada con bundle ID `com.whatsappsalesautomation.app` y el perfil EAS necesario.

## Configuración del webhook

La app iOS no cambia el webhook. Meta debe seguir apuntando al backend publicado:

`https://whatsapp-sal-gvqunbuq.manus.space/api/webhooks/whatsapp`
